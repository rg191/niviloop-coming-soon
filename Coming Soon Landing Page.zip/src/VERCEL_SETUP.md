# 🚀 Vercel Deployment - Niviloop Coming Soon

## Quick Setup (5 perc)

### 1. GitHub Repository létrehozása
1. Menj a [github.com/new](https://github.com/new)
2. Repository név: `niviloop-coming-soon`
3. Public vagy Private - választás
4. Create repository

### 2. Fájlok feltöltése GitHub-ra

**Root directory fájlok:**
```bash
package.json          ✅ Dependencies
vite.config.ts        ✅ Build config
index.html           ✅ HTML entry
vercel.json          ✅ Vercel config
App.tsx              ✅ Main app
```

**Mappák és fájlok:**
```bash
src/
  └── main.tsx        ✅ React entry
  
styles/
  └── globals.css     ✅ Tailwind CSS
  
public/
  └── favicon.svg     ✅ Logo
  
components/
  ├── OptimizedAnimatedLogo.tsx       ✅
  ├── OptimizedBackgroundShapes.tsx   ✅
  ├── OptimizedCountdownTimer.tsx     ✅
  ├── OptimizedFloatingParticles.tsx  ✅
  ├── OptimizedInteractiveBackground.tsx ✅
  └── ui/                            ✅ (összes ShadCN komponens)
```

### 3. Vercel Deployment

1. **Vercel.com** → Sign up (GitHub account-tal)
2. **New Project** → **Import Git Repository**
3. **GitHub repo kiválasztása:** `niviloop-coming-soon`
4. **Deploy** gomb → 2 perc alatt kész!

### 4. Domain hozzáadása

1. **Project Settings** → **Domains**
2. **Add Domain:** `yourdomain.com`
3. **DNS Records beállítása:**

```bash
# A Record
Type: A
Name: @
Value: 76.76.19.61

# CNAME Record  
Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

### 5. Automatikus SSL

- ✅ Vercel automatikusan beállítja
- ✅ HTTPS működik azonnal
- ✅ Worldwide CDN

## ⚡ Gyors parancsok

```bash
# Git repository klónozása
git clone https://github.com/yourusername/niviloop-coming-soon
cd niviloop-coming-soon

# Fájlok hozzáadása
git add .
git commit -m "Initial Niviloop coming soon page"
git push origin main
```

## 🎯 Eredmény

**Live URL:** `https://yourdomain.com`
**Vercel URL:** `https://niviloop-coming-soon.vercel.app`

**Features:**
- ✅ iOS-26 inspirált design
- ✅ Frosted glass effects
- ✅ Countdown timer (2025/10/01)
- ✅ Email subscription
- ✅ Performance optimized
- ✅ Mobile responsive
- ✅ GDPR/Imprint links

## 📧 Email Setup (Opcionális)

Email-ek jelenleg console.log-ba mennek. Production-hez:

1. **EmailJS** integrálás
2. **Formspree** backend
3. **Supabase** database
4. Vagy **hello@niviloop.com** forward

## Support

Ha elakadsz, írd meg! 🚀