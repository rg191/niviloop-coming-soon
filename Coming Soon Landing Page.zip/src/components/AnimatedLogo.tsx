import { motion } from 'motion/react';

export function AnimatedLogo() {
  return (
    <div className="text-center mb-8">
      <motion.div 
        className="inline-block bg-white/15 backdrop-blur-sm rounded-2xl px-8 py-4 border border-white/20 overflow-hidden relative"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        whileHover={{ scale: 1.05 }}
      >
        {/* Animated background gradient */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-[#A4FF4F]/20 via-transparent to-[#A4FF4F]/20"
          animate={{
            x: ['-100%', '100%'],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "linear"
          }}
        />
        
        <motion.h1 
          className="text-2xl font-medium text-[#A4FF4F] tracking-wide relative z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
        >
          {['n', 'i', 'v', 'i', 'l', 'o', 'o', 'p'].map((letter, index) => (
            <motion.span
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                delay: 0.5 + index * 0.1,
                duration: 0.5,
                ease: "easeOut"
              }}
              className="inline-block"
              whileHover={{
                y: -5,
                color: '#ffffff',
                transition: { duration: 0.2 }
              }}
            >
              {letter}
            </motion.span>
          ))}
        </motion.h1>
        
        <motion.div 
          className="text-sm text-white/70 mt-1 tracking-widest relative z-10"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.3, duration: 0.5 }}
        >
          COMMUNICATIONS
        </motion.div>
      </motion.div>
    </div>
  );
}