import { motion } from 'motion/react';
import { useMemo } from 'react';

export function OptimizedBackgroundShapes() {
  // Memoize animation variants for better performance
  const animationVariants = useMemo(() => ({
    shape1: {
      scale: [1, 1.1, 1],
      x: [0, 30, 0],
      y: [0, -20, 0],
    },
    shape2: {
      scale: [1, 1.2, 1],
      x: [0, -25, 0],
      y: [0, 25, 0],
    },
    shape3: {
      scale: [1, 1.05, 1],
      rotate: [0, 90, 180],
    },
    accentOrb: {
      scale: [1, 1.3, 1],
      opacity: [0.1, 0.2, 0.1],
    }
  }), []);

  const transitionConfig = useMemo(() => ({
    duration: 12,
    repeat: Infinity,
    ease: "easeInOut" as const
  }), []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Optimized navy gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900" />
      
      {/* Reduced number of organic glowing shapes with hardware acceleration */}
      <motion.div 
        className="absolute top-1/4 left-1/4 w-80 h-80 bg-gradient-to-r from-blue-500/15 to-purple-500/15 rounded-full blur-3xl opacity-30 will-change-transform"
        animate={animationVariants.shape1}
        transition={{ ...transitionConfig, duration: 10 }}
      />
      
      <motion.div 
        className="absolute top-3/4 right-1/4 w-64 h-64 bg-gradient-to-l from-indigo-500/10 to-blue-600/10 rounded-full blur-3xl opacity-25 will-change-transform"
        animate={animationVariants.shape2}
        transition={{ ...transitionConfig, duration: 14, delay: 1 }}
      />
      
      <motion.div 
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[400px] h-[200px] bg-gradient-to-r from-slate-700/8 to-blue-800/8 rounded-full blur-3xl opacity-15 will-change-transform"
        animate={animationVariants.shape3}
        transition={{ ...transitionConfig, duration: 20, delay: 0.5 }}
      />

      {/* Single lime green accent orb for performance */}
      <motion.div 
        className="absolute top-1/3 right-1/3 w-24 h-24 bg-[#A4FF4F]/8 rounded-full blur-xl will-change-transform"
        animate={animationVariants.accentOrb}
        transition={{ ...transitionConfig, duration: 8 }}
      />
      
      {/* Simplified SVG shapes with reduced complexity */}
      <svg 
        className="absolute top-0 left-0 w-full h-full opacity-8" 
        viewBox="0 0 1200 800"
        style={{ willChange: 'transform' }}
      >
        <defs>
          <linearGradient id="optimizedGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.15" />
            <stop offset="50%" stopColor="#A4FF4F" stopOpacity="0.08" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0.05" />
          </linearGradient>
          <linearGradient id="optimizedGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e40af" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#3730a3" stopOpacity="0.06" />
          </linearGradient>
        </defs>
        
        {/* Simplified static organic shapes for better performance */}
        <path
          d="M200,150 C280,120 360,180 330,260 C300,340 220,310 180,230 C140,150 180,120 200,150 Z"
          fill="url(#optimizedGradient1)"
          className="animate-pulse"
          style={{ animationDuration: '8s' }}
        />
        
        <path
          d="M800,400 C880,370 960,430 930,510 C900,590 820,560 780,480 C740,400 780,370 800,400 Z"
          fill="url(#optimizedGradient2)"
          className="animate-pulse"
          style={{ animationDuration: '12s', animationDelay: '2s' }}
        />
      </svg>
    </div>
  );
}