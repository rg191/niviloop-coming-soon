import { motion } from 'motion/react';

export function BackgroundShapes() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {/* Navy gradient background with subtle animation */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900"
        animate={{
          background: [
            'linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #0f172a 100%)',
            'linear-gradient(135deg, #1e3a8a 0%, #0f172a 50%, #1e3a8a 100%)',
            'linear-gradient(135deg, #0f172a 0%, #1e3a8a 50%, #0f172a 100%)'
          ]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      {/* Enhanced organic glowing shapes with motion */}
      <motion.div 
        className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-3xl opacity-40"
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      <motion.div 
        className="absolute top-3/4 right-1/4 w-80 h-80 bg-gradient-to-l from-indigo-500/15 to-blue-600/15 rounded-full blur-3xl opacity-30"
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -40, 0],
          y: [0, 40, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 2
        }}
      />
      
      <motion.div 
        className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-gradient-to-r from-slate-700/10 to-blue-800/10 rounded-full blur-3xl opacity-20"
        animate={{
          scale: [1, 1.1, 1],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "linear",
          delay: 1
        }}
      />

      {/* Lime green accent orbs */}
      <motion.div 
        className="absolute top-1/3 right-1/3 w-32 h-32 bg-[#A4FF4F]/10 rounded-full blur-2xl"
        animate={{
          scale: [1, 1.5, 1],
          opacity: [0.1, 0.3, 0.1],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      
      {/* Enhanced Loop-like organic forms with motion */}
      <motion.svg 
        className="absolute top-0 left-0 w-full h-full opacity-15" 
        viewBox="0 0 1200 800"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
      >
        <defs>
          <linearGradient id="loopGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
            <stop offset="50%" stopColor="#A4FF4F" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0.1" />
          </linearGradient>
          <linearGradient id="loopGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e40af" stopOpacity="0.3" />
            <stop offset="50%" stopColor="#A4FF4F" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#3730a3" stopOpacity="0.1" />
          </linearGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge> 
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        {/* Enhanced organic loop shapes */}
        <motion.path
          d="M200,150 C300,100 400,200 350,300 C300,400 200,350 150,250 C100,150 150,100 200,150 Z"
          fill="url(#loopGradient1)"
          filter="url(#glow)"
          animate={{
            d: [
              "M200,150 C300,100 400,200 350,300 C300,400 200,350 150,250 C100,150 150,100 200,150 Z",
              "M220,170 C320,120 420,220 370,320 C320,420 220,370 170,270 C120,170 170,120 220,170 Z",
              "M200,150 C300,100 400,200 350,300 C300,400 200,350 150,250 C100,150 150,100 200,150 Z"
            ]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        
        <motion.path
          d="M800,400 C900,350 1000,450 950,550 C900,650 800,600 750,500 C700,400 750,350 800,400 Z"
          fill="url(#loopGradient2)"
          filter="url(#glow)"
          animate={{
            d: [
              "M800,400 C900,350 1000,450 950,550 C900,650 800,600 750,500 C700,400 750,350 800,400 Z",
              "M780,380 C880,330 980,430 930,530 C880,630 780,580 730,480 C680,380 730,330 780,380 Z",
              "M800,400 C900,350 1000,450 950,550 C900,650 800,600 750,500 C700,400 750,350 800,400 Z"
            ]
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
        
        <motion.path
          d="M500,600 C600,550 700,650 650,750 C600,800 500,750 450,650 C400,550 450,500 500,600 Z"
          fill="url(#loopGradient1)"
          filter="url(#glow)"
          animate={{
            d: [
              "M500,600 C600,550 700,650 650,750 C600,800 500,750 450,650 C400,550 450,500 500,600 Z",
              "M520,620 C620,570 720,670 670,770 C620,820 520,770 470,670 C420,570 470,520 520,620 Z",
              "M500,600 C600,550 700,650 650,750 C600,800 500,750 450,650 C400,550 450,500 500,600 Z"
            ]
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 4
          }}
        />
      </motion.svg>
    </div>
  );
}