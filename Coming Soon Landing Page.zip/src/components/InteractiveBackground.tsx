import { useEffect, useRef } from 'react';

export function InteractiveBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    let mouseX = 0;
    let mouseY = 0;
    let time = 0;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
    };

    window.addEventListener('mousemove', handleMouseMove);

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      time += 0.01;

      // Create flowing energy lines that follow mouse
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(164, 255, 79, ${0.1 + i * 0.05})`;
        ctx.lineWidth = 2 - i * 0.3;

        const offsetX = Math.sin(time + i) * 100;
        const offsetY = Math.cos(time + i * 0.7) * 50;
        
        const startX = mouseX + offsetX;
        const startY = mouseY + offsetY;
        
        for (let j = 0; j < 50; j++) {
          const x = startX + Math.sin(time + j * 0.1) * (100 + i * 30);
          const y = startY + Math.cos(time + j * 0.08) * (60 + i * 20);
          
          if (j === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        
        ctx.stroke();
      }

      // Pulsing circles around mouse
      for (let i = 0; i < 2; i++) {
        const radius = 50 + Math.sin(time * 2 + i) * 20;
        ctx.beginPath();
        ctx.arc(mouseX, mouseY, radius + i * 30, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(164, 255, 79, ${0.1 - i * 0.05})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-5"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}