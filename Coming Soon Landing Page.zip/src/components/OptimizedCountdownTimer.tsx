import { useState, useEffect, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function OptimizedCountdownTimer() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Memoize target date calculation
  const targetDate = useMemo(() => new Date('2025-10-01T00:00:00'), []);

  // Memoize animation variants
  const timerVariants = useMemo(() => ({
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 }
  }), []);

  const calculateTimeLeft = useCallback(() => {
    const now = new Date().getTime();
    const distance = targetDate.getTime() - now;

    if (distance > 0) {
      return {
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
      };
    }
    return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  }, [targetDate]);

  useEffect(() => {
    // Initial calculation
    setTimeLeft(calculateTimeLeft());

    // Use more efficient interval - only update what's necessary
    const timer = setInterval(() => {
      const newTimeLeft = calculateTimeLeft();
      setTimeLeft(prevTime => {
        // Only update if values actually changed
        if (JSON.stringify(prevTime) !== JSON.stringify(newTimeLeft)) {
          return newTimeLeft;
        }
        return prevTime;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [calculateTimeLeft]);

  // Memoize the timer units to prevent unnecessary re-renders
  const timerUnits = useMemo(() => 
    Object.entries(timeLeft).map(([unit, value], index) => ({
      unit,
      value,
      index
    })), [timeLeft]);

  return (
    <div className="flex justify-center gap-4 my-8 flex-wrap">
      {timerUnits.map(({ unit, value, index }) => (
        <motion.div 
          key={unit} 
          className="text-center"
          initial={timerVariants.initial}
          animate={timerVariants.animate}
          transition={{ delay: index * 0.1, duration: 0.5 }}
        >
          <motion.div 
            className="bg-white/10 backdrop-blur-sm rounded-xl p-3 min-w-[70px] border border-white/20 relative overflow-hidden group cursor-pointer will-change-transform"
            whileHover={{ 
              scale: 1.03, 
              backgroundColor: 'rgba(164, 255, 79, 0.08)',
              borderColor: 'rgba(164, 255, 79, 0.2)'
            }}
            transition={{ duration: 0.2 }}
          >
            <div className="relative z-10">
              <AnimatePresence mode="wait">
                <motion.div
                  key={value}
                  className="text-2xl font-medium text-white mb-1"
                  variants={timerVariants}
                  initial="initial"
                  animate="animate"
                  exit="exit"
                  transition={{ duration: 0.2, ease: "easeOut" }}
                >
                  {value.toString().padStart(2, '0')}
                </motion.div>
              </AnimatePresence>
              
              <div className="text-xs text-white/70 uppercase tracking-wide">
                {unit}
              </div>
            </div>

            {/* Simplified pulse effect only for seconds */}
            {unit === 'seconds' && (
              <motion.div
                className="absolute inset-0 border border-[#A4FF4F] rounded-xl opacity-20"
                animate={{
                  scale: [1, 1.05, 1],
                  opacity: [0.2, 0.1, 0.2]
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            )}
          </motion.div>
        </motion.div>
      ))}
    </div>
  );
}