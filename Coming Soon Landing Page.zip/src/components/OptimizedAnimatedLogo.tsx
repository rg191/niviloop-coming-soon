import { motion } from 'motion/react';
import { useMemo } from 'react';

export function OptimizedAnimatedLogo() {
  // Memoize letter data to prevent recreation on each render
  const letterData = useMemo(() => 
    ['n', 'i', 'v', 'i', 'l', 'o', 'o', 'p'].map((letter, index) => ({
      letter,
      index,
      delay: 0.5 + index * 0.08 // Slightly reduced stagger
    })), []);

  // Memoize animation variants
  const containerVariants = useMemo(() => ({
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 }
  }), []);

  const letterVariants = useMemo(() => ({
    initial: { opacity: 0, y: 15 },
    animate: { opacity: 1, y: 0 }
  }), []);

  return (
    <div className="text-center mb-8">
      <motion.div 
        className="inline-block bg-white/15 backdrop-blur-sm rounded-xl px-6 py-3 border border-white/20 overflow-hidden relative will-change-transform"
        variants={containerVariants}
        initial="initial"
        animate="animate"
        transition={{ duration: 0.6, ease: "easeOut" }}
        whileHover={{ scale: 1.02 }}
      >
        {/* Simplified background gradient - no animation for better performance */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#A4FF4F]/10 via-transparent to-[#A4FF4F]/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        <motion.h1 
          className="text-xl font-medium text-[#A4FF4F] tracking-wide relative z-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          {letterData.map(({ letter, index, delay }) => (
            <motion.span
              key={index}
              variants={letterVariants}
              initial="initial"
              animate="animate"
              transition={{
                delay,
                duration: 0.4,
                ease: "easeOut"
              }}
              className="inline-block will-change-transform"
              whileHover={{
                y: -3,
                color: '#ffffff',
                transition: { duration: 0.15 }
              }}
            >
              {letter}
            </motion.span>
          ))}
        </motion.h1>
        
        <motion.div 
          className="text-xs text-white/70 mt-1 tracking-widest relative z-10"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1, duration: 0.4 }}
        >
          COMMUNICATIONS
        </motion.div>
      </motion.div>
    </div>
  );
}