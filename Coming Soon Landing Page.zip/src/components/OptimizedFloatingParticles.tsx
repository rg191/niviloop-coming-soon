import { useEffect, useState, useMemo, useRef } from 'react';

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  opacity: number;
  velocityX: number;
  velocityY: number;
  color: string;
}

export function OptimizedFloatingParticles() {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [isVisible, setIsVisible] = useState(true);
  const animationRef = useRef<number>();
  const lastUpdateRef = useRef<number>(0);

  // Reduce particle count and optimize colors
  const particleColors = useMemo(() => ['#A4FF4F', '#3b82f6', '#6366f1', '#ffffff'], []);

  useEffect(() => {
    // Visibility API to pause animations when tab is not active
    const handleVisibilityChange = () => {
      setIsVisible(!document.hidden);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Reduce particle count for better performance
    const initialParticles: Particle[] = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      size: Math.random() * 3 + 1,
      opacity: Math.random() * 0.4 + 0.1,
      velocityX: (Math.random() - 0.5) * 0.3,
      velocityY: (Math.random() - 0.5) * 0.3,
      color: particleColors[Math.floor(Math.random() * particleColors.length)]
    }));

    setParticles(initialParticles);

    const animate = (currentTime: number) => {
      // Throttle animation to ~30fps for better performance
      if (currentTime - lastUpdateRef.current < 33) {
        animationRef.current = requestAnimationFrame(animate);
        return;
      }

      lastUpdateRef.current = currentTime;

      if (isVisible) {
        setParticles(prev => prev.map(particle => {
          let newX = particle.x + particle.velocityX;
          let newY = particle.y + particle.velocityY;

          // Wrap around screen edges
          if (newX < 0) newX = window.innerWidth;
          if (newX > window.innerWidth) newX = 0;
          if (newY < 0) newY = window.innerHeight;
          if (newY > window.innerHeight) newY = 0;

          return {
            ...particle,
            x: newX,
            y: newY
          };
        }));
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isVisible, particleColors]);

  // Use CSS transforms for better performance
  const particleElements = useMemo(() => 
    particles.map(particle => (
      <div
        key={particle.id}
        className="absolute rounded-full blur-sm pointer-events-none will-change-transform"
        style={{
          transform: `translate3d(${particle.x}px, ${particle.y}px, 0)`,
          width: particle.size,
          height: particle.size,
          backgroundColor: particle.color,
          opacity: particle.opacity,
        }}
      />
    )), [particles]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-5">
      {particleElements}
    </div>
  );
}