import { useEffect, useRef, useCallback } from 'react';

export function OptimizedInteractiveBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const animationRef = useRef<number>();
  const isVisibleRef = useRef(true);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    mouseRef.current = { x: e.clientX, y: e.clientY };
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const resizeCanvas = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      
      ctx.scale(dpr, dpr);
      canvas.style.width = rect.width + 'px';
      canvas.style.height = rect.height + 'px';
    };

    resizeCanvas();

    // Visibility API optimization
    const handleVisibilityChange = () => {
      isVisibleRef.current = !document.hidden;
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    let time = 0;
    let lastFrameTime = 0;

    const animate = (currentTime: number) => {
      // Skip frame if tab is not visible
      if (!isVisibleRef.current) {
        animationRef.current = requestAnimationFrame(animate);
        return;
      }

      // Throttle to ~30fps for better performance
      if (currentTime - lastFrameTime < 33) {
        animationRef.current = requestAnimationFrame(animate);
        return;
      }

      lastFrameTime = currentTime;
      time += 0.01;

      // Clear with optimized clearing
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const { x: mouseX, y: mouseY } = mouseRef.current;

      // Simplified energy lines (reduced from 3 to 2)
      for (let i = 0; i < 2; i++) {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(164, 255, 79, ${0.08 + i * 0.03})`;
        ctx.lineWidth = 1.5 - i * 0.2;

        const offsetX = Math.sin(time + i) * 80;
        const offsetY = Math.cos(time + i * 0.7) * 40;
        
        const startX = mouseX + offsetX;
        const startY = mouseY + offsetY;
        
        // Reduced line segments for better performance
        for (let j = 0; j < 30; j++) {
          const x = startX + Math.sin(time + j * 0.15) * (80 + i * 25);
          const y = startY + Math.cos(time + j * 0.12) * (50 + i * 15);
          
          if (j === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        
        ctx.stroke();
      }

      // Single pulsing circle around mouse (reduced from 2)
      const radius = 40 + Math.sin(time * 2) * 15;
      ctx.beginPath();
      ctx.arc(mouseX, mouseY, radius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(164, 255, 79, 0.06)`;
      ctx.lineWidth = 1;
      ctx.stroke();

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [handleMouseMove]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-5 w-full h-full"
      style={{ mixBlendMode: 'screen' }}
    />
  );
}