import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });
  const [prevTimeLeft, setPrevTimeLeft] = useState(timeLeft);

  useEffect(() => {
    // Set target date to October 1, 2025
    const targetDate = new Date('2025-10-01T00:00:00');

    const timer = setInterval(() => {
      const now = new Date().getTime();
      const distance = targetDate.getTime() - now;

      if (distance > 0) {
        const newTimeLeft = {
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        };
        
        setPrevTimeLeft(timeLeft);
        setTimeLeft(newTimeLeft);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  return (
    <div className="flex justify-center gap-6 my-8 flex-wrap">
      {Object.entries(timeLeft).map(([unit, value], index) => (
        <motion.div 
          key={unit} 
          className="text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1, duration: 0.5 }}
        >
          <motion.div 
            className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 min-w-[80px] border border-white/20 relative overflow-hidden group cursor-pointer"
            whileHover={{ 
              scale: 1.05, 
              backgroundColor: 'rgba(164, 255, 79, 0.1)',
              borderColor: 'rgba(164, 255, 79, 0.3)'
            }}
            transition={{ duration: 0.2 }}
          >
            {/* Animated shine effect on hover */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100"
              initial={{ x: '-100%' }}
              whileHover={{ x: '100%' }}
              transition={{ duration: 0.6 }}
            />
            
            <div className="relative z-10">
              <AnimatePresence mode="wait">
                <motion.div
                  key={value}
                  className="text-3xl font-medium text-white mb-1"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  {value.toString().padStart(2, '0')}
                </motion.div>
              </AnimatePresence>
              
              <motion.div 
                className="text-sm text-white/70 uppercase tracking-wide"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 + index * 0.1 }}
              >
                {unit}
              </motion.div>
            </div>

            {/* Pulse effect for seconds */}
            {unit === 'seconds' && (
              <motion.div
                className="absolute inset-0 border-2 border-[#A4FF4F] rounded-2xl opacity-30"
                animate={{
                  scale: [1, 1.1, 1],
                  opacity: [0.3, 0.1, 0.3]
                }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            )}
          </motion.div>
        </motion.div>
      ))}
    </div>
  );
}