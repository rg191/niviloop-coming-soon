# 🚀 Domain Deployment Útmutató - Niviloop Coming Soon

## Gyors Deployment Opciók

### 1. **Vercel (Ajánlott) - 2 perc**
```bash
# 1. Regisztrálj Vercel-en: vercel.com
# 2. GitHub repo létrehozása ezekkel a fájlokkal
# 3. Vercel Dashboard → New Project → Import from GitHub
# 4. Domain Settings → Add Domain → yourdomain.com
```

**Előnyök:**
- Ingyenes SSL tanúsítvány
- Automatikus deployments
- CDN világszerte
- 99.99% uptime

### 2. **Netlify - 3 perc**
```bash
# 1. Regisztrálj Netlify-on: netlify.com
# 2. Drag & drop a fájlokat a Deploy oldalon
# 3. Site Settings → Domain management → Add custom domain
```

### 3. **GitHub Pages - 5 perc**
```bash
# 1. GitHub repo létrehozása
# 2. Settings → Pages → Source: Deploy from branch
# 3. Custom domain beállítása
```

## Domain DNS Beállítások

### A Records (IP cím alapú)
```
Type: A
Name: @
Value: [hosting provider IP]
TTL: 3600
```

### CNAME Records (subdomain)
```
Type: CNAME  
Name: www
Value: your-project.vercel.app
TTL: 3600
```

## Gyors Start - Vercel (Legegyszerűbb)

### 1. Fájlok előkészítése
- Másold ki az összes fájlt egy mappába
- package.json hozzáadása (lásd lent)

### 2. Vercel Deploy
- vercel.com → Sign up with GitHub
- Import repository
- Deploy → instant!

### 3. Domain hozzáadása
- Project Settings → Domains
- Add yourdomain.com + www.yourdomain.com
- DNS rekordok beállítása (Vercel megmutatja)

## Alternatív: Subdomain Használata

Ha nem akarod megváltoztatni a fő domain beállításait:

```
coming-soon.yourdomain.com
temp.yourdomain.com  
launch.yourdomain.com
```

**Előny:** A fő domain érintetlen marad!

## Monitoring & Analytics

### Google Analytics hozzáadása (opcionális)
```html
<!-- Rakd be az index.html <head> részébe -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

## Email Funkció (Production)

Jelenleg mock funkcióval működik. Production-höz:

1. **EmailJS** (egyszerű)
2. **Formspree** (form backend)  
3. **Supabase** (teljes backend)
4. **Netlify Forms** (ha Netlify-t használsz)

## Költségek 💰

- **Vercel:** Ingyenes (hobby tier)
- **Netlify:** Ingyenes (100GB/hó)
- **GitHub Pages:** Teljesen ingyenes
- **Domain:** Csak a meglévő domain költsége

## Következő Lépések

1. ✅ Válassz hosting platformot
2. ✅ Deploy the coming soon page  
3. ✅ DNS beállítások
4. ✅ SSL ellenőrzés
5. ✅ Email testing
6. 🚀 Launch!

**Időszükséglet:** 5-15 perc összesen
**Üzemidő:** 1-2 óra a DNS propagációval együtt