
  # Coming Soon Landing Page

  This is a code bundle for Coming Soon Landing Page. The original project is available at https://www.figma.com/design/W6wiRLH2v6AtDfygzXrFoJ/Coming-Soon-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  